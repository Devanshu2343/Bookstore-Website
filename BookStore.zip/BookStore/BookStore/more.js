const express = require('express');
const bodyParser = require('body-parser');

const app = express();


app.use(bodyParser.urlencoded({ extended: true }));


app.get('/', (req, res) => {
  const htmlContent = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
      <title>Suggestion Form - Magalam BookStore</title>
      <style>
      
        body {
            font-family: 'Courier New', Courier, monospace;
            background: linear-gradient(135deg, #fc6076, #ff9a44); 
            color: #ffffffe8;
            margin: 0;
            padding: 0;
          }
      
          .header {
            text-align: center;
            padding-top: 50px;
            font-size: 50px;
            letter-spacing: 3px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
          }
      
          .container-fluid {
            margin: 20px;
            text-align: center;
          }
      
          ul {
            list-style: none;
            padding: 0;
            margin: 0;
          }
      
          li {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 25px;
            background-color: rgba(255, 255, 255, 0.3);
            margin: 5px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s, color 0.3s; 
          }
      
          li:hover {
            background-color: rgba(255, 255, 255, 0.7);
            color: #333;
          }
      
          .container {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
          }
      
          .suggestion-info {
            flex: 1;
            padding: 20px;
            text-align: center;
            margin: 20px;
            border-radius: 20px; 
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3); 
            background: linear-gradient(135deg, #0dadad77, #2ca806);
          }
      
          .suggestion-info h1 {
            margin: 0;
            font-size: 30px;
            color: #fff; 
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
          }
      
          .suggestion-info p {
            font-size: 18px; 
            line-height: 1.5;
            color: #fff;
          }
      
          .suggestion-form {
            flex: 1;
            padding: 20px;
            margin: 20px;
            border-radius: 20px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3); 
            background: linear-gradient(135deg, #0dadad77, #2ca806); 
          }
      
          .suggestion-form h1 {
            margin: 0;
            font-size: 30px; 
            color: #fff; 
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
          }
      
          .suggestion-form input,
          .suggestion-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px; 
            background-color: transparent; 
            color: #fff; 
          }
      
          .suggestion-form button {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 5px;
            background-color: #007bff; 
            color: #fff; 
            font-size: 20px;
            font-weight: bold; 
            cursor: pointer;
            transition: background-color 0.3s ease;
          }
      
          .suggestion-form button:hover {
            background-color: #0056b3; 
          }
      </style>
    </head>
    <body>
      <h1 class="header">Magalam BookStore</h1>
      <div class="container-fluid">
      <ul class="list-inline justify-content-center"> 
        <li><a href="mainpage.html" style="text-decoration: none; color: #fff;">Home</a></li>
        <li><a href="about.html" style="text-decoration: none; color: #fff;">About</a></li>
        <li><a href="contact.html" style="text-decoration: none; color: #fff;">Contact Us</a></li>
        <li><a href="more.html" style="text-decoration: none; color: #fff;">More</a></li>
      </ul>
    </div>
      <div class="container">
        <div class="suggestion-info">
          <h1><b>Suggest Us</b></h1>
          <h5>We value your feedback!</h5>
          <p>If you have any suggestions or comments about our services, please feel free to share them with us.</p>
        </div>
        <div class="suggestion-form">
          <h1>Please!!! Submit Your Suggestion</h1>
          <form action="/submit-suggestion" method="post">
            <div>
              <textarea id="suggestion" name="suggestion" required></textarea>
            </div>
            <div>
              <button type="submit">Submit Suggestion</button>
            </div>
          </form>
        </div>
      </div>
    </body>
    </html>
  `;
  
  res.send(htmlContent);
});


app.post('/submit-suggestion', (req, res) => {
  
  const suggestion = req.body.suggestion;

  
  console.log('Received suggestion:', suggestion);

 
  res.send('Suggestion received successfully!');
});


const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
